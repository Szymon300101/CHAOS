#include "SetupDial.h"

//(*InternalHeaders(SetupDial)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(SetupDial)
const long SetupDial::ID_SPINCTRL1 = wxNewId();
const long SetupDial::ID_STATICTEXT1 = wxNewId();
const long SetupDial::ID_SLIDER1 = wxNewId();
const long SetupDial::ID_STATICTEXT2 = wxNewId();
const long SetupDial::ID_STATICTEXT3 = wxNewId();
const long SetupDial::ID_RADIOBOX1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(SetupDial,wxDialog)
	//(*EventTable(SetupDial)
	//*)
END_EVENT_TABLE()

SetupDial::SetupDial(wxWindow* parent,wxWindowID id,const wxPoint& pos,const wxSize& size)
{
	//(*Initialize(SetupDial)
	Create(parent, id, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("id"));
	SetClientSize(wxSize(235,182));
	Move(wxDefaultPosition);
	Button1 = new wxButton(this, wxID_OK, _("START"), wxPoint(8,152), wxDefaultSize, 0, wxDefaultValidator, _T("wxID_OK"));
	CornNum = new wxSpinCtrl(this, ID_SPINCTRL1, _T("3"), wxPoint(8,24), wxSize(88,21), 0, 3, 16, 3, _T("ID_SPINCTRL1"));
	CornNum->SetValue(_T("3"));
	StaticText1 = new wxStaticText(this, ID_STATICTEXT1, _("Number of corners:"), wxPoint(8,8), wxDefaultSize, 0, _T("ID_STATICTEXT1"));
	Slider2 = new wxSlider(this, ID_SLIDER1, 100000, 10000, 1000000, wxPoint(112,24), wxSize(104,16), 0, wxDefaultValidator, _T("ID_SLIDER1"));
	StaticText2 = new wxStaticText(this, ID_STATICTEXT2, _("Number of pionts:"), wxPoint(120,8), wxDefaultSize, 0, _T("ID_STATICTEXT2"));
	Points = new wxStaticText(this, ID_STATICTEXT3, _("100000"), wxPoint(144,40), wxDefaultSize, 0, _T("ID_STATICTEXT3"));
	wxString __wxRadioBoxChoices_1[2] =
	{
		_("Black on white"),
		_("Colour on white")
	};
	RadioBox1 = new wxRadioBox(this, ID_RADIOBOX1, _("Color"), wxPoint(104,56), wxSize(112,64), 2, __wxRadioBoxChoices_1, 1, 0, wxDefaultValidator, _T("ID_RADIOBOX1"));
	RadioBox1->SetSelection(0);

	Connect(ID_SLIDER1,wxEVT_COMMAND_SLIDER_UPDATED,(wxObjectEventFunction)&SetupDial::OnSlider1CmdScroll);
	Connect(ID_RADIOBOX1,wxEVT_COMMAND_RADIOBOX_SELECTED,(wxObjectEventFunction)&SetupDial::OnRadioBox1Select);
	//*)
}

SetupDial::~SetupDial()
{
	//(*Destroy(SetupDial)
	//*)
}

wxString itos(int);


void SetupDial::OnSlider1CmdScroll(wxScrollEvent& event)
{
    Points->SetLabel(itos(Slider2->GetValue()));
}

void SetupDial::OnRadioBox1Select(wxCommandEvent& event)
{
}
