/***************************************************************
 * Name:      GUI_templateApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Szymon ()
 * Created:   2018-10-21
 * Copyright: Szymon ()
 * License:
 **************************************************************/

#include "GUI_templateApp.h"

//(*AppHeaders
#include "GUI_templateMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(GUI_templateApp);

bool GUI_templateApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	GUI_templateFrame* Frame = new GUI_templateFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
