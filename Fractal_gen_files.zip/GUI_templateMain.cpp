/***************************************************************
 * Name:      GUI_templateMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Szymon ()
 * Created:   2018-10-21
 * Copyright: Szymon ()
 * License:
 **************************************************************/

#include "GUI_templateMain.h"
#include <wx/msgdlg.h>
#include <wx/bitmap.h>
#include <wx/filename.h>
#include <wx/dcmemory.h>
#include <wx/clipbrd.h>
#include <wx/pen.h>
#include <wx/brush.h>
#include "SetupDial.h"
#include <cstdlib>
#include <time.h>
#include <string>

//(*InternalHeaders(GUI_templateFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(GUI_templateFrame)
const long GUI_templateFrame::ID_CUSTOM1 = wxNewId();
const long GUI_templateFrame::ID_CUSTOM2 = wxNewId();
const long GUI_templateFrame::ID_BUTTON1 = wxNewId();
const long GUI_templateFrame::ID_SLIDER1 = wxNewId();
const long GUI_templateFrame::ID_PANEL1 = wxNewId();
const long GUI_templateFrame::idMenuQuit = wxNewId();
const long GUI_templateFrame::idMenuAbout = wxNewId();
const long GUI_templateFrame::idMenuClear = wxNewId();
const long GUI_templateFrame::idMenuSave = wxNewId();
const long GUI_templateFrame::idMenuFractal = wxNewId();
//*)

BEGIN_EVENT_TABLE(GUI_templateFrame,wxFrame)
    //(*EventTable(GUI_templateFrame)
    //*)
END_EVENT_TABLE()

GUI_templateFrame::GUI_templateFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(GUI_templateFrame)
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(300,300));
    Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(144,80), wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    Panel1->SetBackgroundColour(wxColour(255,255,255));
    my_wxclientdc = new wxClientDC(Panel1);
    my_wxmemorydc = new wxMemoryDC();
    SET_button = new wxButton(Panel1, ID_BUTTON1, _("SET"), wxPoint(8,8), wxSize(35,32), 0, wxDefaultValidator, _T("ID_BUTTON1"));
    Slider1 = new wxSlider(Panel1, ID_SLIDER1, 0, 0, 500, wxPoint(48,8), wxSize(72,16), 0, wxDefaultValidator, _T("ID_SLIDER1"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    Menu3 = new wxMenu();
    MenuItem3 = new wxMenuItem(Menu3, idMenuClear, _("&Clear\tSpace"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem3);
    MenuItem5 = new wxMenuItem(Menu3, idMenuSave, _("&Save\tCtrl+s"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem5);
    MenuItem6 = new wxMenuItem(Menu3, idMenuFractal, _("Draw Fractal\tEnter"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem6);
    MenuBar1->Append(Menu3, _("&Image"));
    SetMenuBar(MenuBar1);
    FileDialog1 = new wxFileDialog(this, _("Select file"), wxEmptyString, wxEmptyString, wxFileSelectorDefaultWildcardStr, wxFD_DEFAULT_STYLE, wxDefaultPosition, wxDefaultSize, _T("wxFileDialog"));
    FileDialog2 = new wxFileDialog(this, _("Select file"), wxEmptyString, wxEmptyString, _("JPEG files|*.jpeg|PNG files|*.png|BMP files|*.bmp"), wxFD_DEFAULT_STYLE, wxDefaultPosition, wxDefaultSize, _T("wxFileDialog"));

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&GUI_templateFrame::OnSET_buttonClick);
    Connect(ID_SLIDER1,wxEVT_COMMAND_SLIDER_UPDATED,(wxObjectEventFunction)&GUI_templateFrame::OnSlider1CmdScrollChanged);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUI_templateFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUI_templateFrame::OnAbout);
    //*)
    //Panel1->SetSize(500,300);
    Connect(idMenuClear,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUI_templateFrame::OnClear);
    Connect(idMenuSave,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUI_templateFrame::OnSave);
    Connect(idMenuFractal,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&GUI_templateFrame::OnSET_buttonClick);

}

wxString itos(int in)
	{
	    wxString s;
	  char buffer [50];
	 sprintf (buffer, "%d", in);
	    s=buffer;
	  return s;
	}
    struct RGB{ byte r,g,b;};
	RGB hsvToRgb(uint16_t h, uint8_t s, uint8_t v)
{
    uint8_t f = (h % 60) * 255 / 60;
    uint8_t p = (255 - s) * (uint16_t)v / 255;
    uint8_t q = (255 - f * (uint16_t)s / 255) * (uint16_t)v / 255;
    uint8_t t = (255 - (255 - f) * (uint16_t)s / 255) * (uint16_t)v / 255;
    uint8_t r = 0, g = 0, b = 0;
    switch((h / 60) % 6){
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        case 5: r = v; g = p; b = q; break;
    }
    return (RGB){r, g, b};
}

GUI_templateFrame::~GUI_templateFrame()
{
    //(*Destroy(GUI_templateFrame)
    //*)
}

void GUI_templateFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void GUI_templateFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void GUI_templateFrame::OnClear(wxCommandEvent& event)
{
    my_wxclientdc->Clear();
    SET_button->Show(true);
    Slider1->Show(true);
}

void GUI_templateFrame::OnSave(wxCommandEvent& event)
{
    wxBitmap my_bitmap_tmp(Panel1->GetSize(),wxBITMAP_SCREEN_DEPTH);        my_wxmemorydc->SelectObject(my_bitmap_tmp);        my_wxmemorydc->Blit(wxPoint(0,0),Panel1->GetSize(),my_wxclientdc,wxPoint(0,0),wxCOPY,true,wxDefaultPosition);        int dlg=FileDialog2->ShowModal();        if(dlg==wxID_OK)        {            wxFileName my_file(FileDialog2->GetPath());            wxString my_file_ext=my_file.GetExt().Lower();            if(my_file_ext==wxT("xpm"))my_bitmap_tmp.SaveFile(FileDialog2->GetPath(),wxBITMAP_TYPE_XPM,NULL);            else if(my_file_ext==wxT("jpeg"))my_bitmap_tmp.SaveFile(FileDialog2->GetPath(),wxBITMAP_TYPE_JPEG,NULL);            else if(my_file_ext==wxT("bmp"))my_bitmap_tmp.SaveFile(FileDialog2->GetPath(),wxBITMAP_TYPE_BMP,NULL);            else wxMessageBox(wxT("Extension ERROR"),wxT("ERROR"));        }
}
void GUI_templateFrame::OnSlider1CmdScrollChanged(wxScrollEvent& event)
{
    Panel1->SetSize(Slider1->GetValue()+300,Slider1->GetValue()+300);
    SetClientSize(wxSize(Slider1->GetValue()+300,Slider1->GetValue()+300));
}

void GUI_templateFrame::OnSET_buttonClick(wxCommandEvent& event)
{
        SetupDial tmp_dlg(this);
	    int dlg = tmp_dlg.ShowModal();
	    if(dlg==wxID_OK)
	    {
	        int x,y;
	        GetClientSize(&x,&y);
	        Slider1->Hide();
	        SET_button->Hide();
	        MakeFractal(x,y,tmp_dlg.CornNum->GetValue(),tmp_dlg.RadioBox1->GetSelection(),tmp_dlg.Slider2->GetValue());
	    }

}

void GUI_templateFrame::MakeFractal(int w, int h,int cNum,int colMode,long long high)
{
    my_wxclientdc->SetPen(wxPen(wxColour(0,0,0,wxALPHA_OPAQUE),wxPENSTYLE_SOLID));
    wxPoint x(rand()%w+1,rand()%h+1);
    wxPoint p[cNum];
    int alfa=360/cNum;
    int r;
    if(h<=w) r=h/2;
    else     r=w/2;
    for(int i=0;i<cNum;i++)
    {
        int beta=alfa*(i+1)-90;
        wxPoint c(w/2,h/2);
        c.x+=r*cos(beta*M_PI/180);
        c.y+=r*sin(beta*M_PI/180);
        p[i]=c;
        //my_wxclientdc->DrawText(itos(beta),c);
    }
    for(long long i=0;i<high;i++)
    {
        int corn=rand()%cNum;
        if(colMode==1)
        {
            RGB col=hsvToRgb(239/cNum*corn,240,120);
            my_wxclientdc->SetPen(wxPen(wxColour(col.r,col.g,col.b,wxALPHA_OPAQUE),wxPENSTYLE_SOLID));
        }
        x.x=(x.x+p[corn].x)/2;
        x.y=(x.y+p[corn].y)/2;
        my_wxclientdc->DrawPoint(x.x,x.y);
    }
}








