/***************************************************************
 * Name:      GUI_templateMain.h
 * Purpose:   Defines Application Frame
 * Author:    Szymon ()
 * Created:   2018-10-21
 * Copyright: Szymon ()
 * License:
 **************************************************************/

#ifndef GUI_TEMPLATEMAIN_H
#define GUI_TEMPLATEMAIN_H

//(*Headers(GUI_templateFrame)
#include <wx/button.h>
#include <wx/filedlg.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/slider.h>
#include <wx\dcclient.h>
#include <wx\dcmemory.h>
//*)

class GUI_templateFrame: public wxFrame
{
    public:

        GUI_templateFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~GUI_templateFrame();

    private:
        void MakeFractal(int,int,int,int,long long);
        //(*Handlers(GUI_templateFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void Onmy_wxmemorydcPaint(wxPaintEvent& event);
        void OnLoad(wxCommandEvent& event);
        void OnClear(wxCommandEvent& event);
        void OnSave(wxCommandEvent& event);
        void OnClose(wxCloseEvent& event);
        void OnSET_buttonClick(wxCommandEvent& event);
        void OnSlider1CmdScrollChanged(wxScrollEvent& event);
        //*)

        //(*Identifiers(GUI_templateFrame)
        static const long ID_CUSTOM1;
        static const long ID_CUSTOM2;
        static const long ID_BUTTON1;
        static const long ID_SLIDER1;
        static const long ID_PANEL1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long idMenuClear;
        static const long idMenuSave;
        static const long idMenuFractal;
        //*)

        //(*Declarations(GUI_templateFrame)
        wxButton* SET_button;
        wxClientDC* my_wxclientdc;
        wxFileDialog* FileDialog1;
        wxFileDialog* FileDialog2;
        wxMemoryDC* my_wxmemorydc;
        wxMenu* Menu3;
        wxMenuItem* MenuItem3;
        wxMenuItem* MenuItem5;
        wxMenuItem* MenuItem6;
        wxPanel* Panel1;
        wxSlider* Slider1;
        //*)

        wxBitmap my_bitmap;
        wxBitmap my_bitmap_tmp;

        DECLARE_EVENT_TABLE()
};

#endif // GUI_TEMPLATEMAIN_H
