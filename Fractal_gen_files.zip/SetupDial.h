#ifndef SETUPDIAL_H
#define SETUPDIAL_H

//(*Headers(SetupDial)
#include <wx/button.h>
#include <wx/dialog.h>
#include <wx/radiobox.h>
#include <wx/slider.h>
#include <wx/spinctrl.h>
#include <wx/stattext.h>
//*)

class SetupDial: public wxDialog
{
	public:

		SetupDial(wxWindow* parent,wxWindowID id=wxID_ANY,const wxPoint& pos=wxDefaultPosition,const wxSize& size=wxDefaultSize);
		virtual ~SetupDial();

		//(*Declarations(SetupDial)
		wxButton* Button1;
		wxRadioBox* RadioBox1;
		wxSlider* Slider2;
		wxSpinCtrl* CornNum;
		wxStaticText* Points;
		wxStaticText* StaticText1;
		wxStaticText* StaticText2;
		//*)

	protected:

		//(*Identifiers(SetupDial)
		static const long ID_SPINCTRL1;
		static const long ID_STATICTEXT1;
		static const long ID_SLIDER1;
		static const long ID_STATICTEXT2;
		static const long ID_STATICTEXT3;
		static const long ID_RADIOBOX1;
		//*)

	private:

		//(*Handlers(SetupDial)
		void OnSlider1CmdScroll(wxScrollEvent& event);
		void OnRadioBox1Select(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
