/***************************************************************
 * Name:      GUI_templateApp.h
 * Purpose:   Defines Application Class
 * Author:    Szymon ()
 * Created:   2018-10-21
 * Copyright: Szymon ()
 * License:
 **************************************************************/

#ifndef GUI_TEMPLATEAPP_H
#define GUI_TEMPLATEAPP_H

#include <wx/app.h>

class GUI_templateApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // GUI_TEMPLATEAPP_H
